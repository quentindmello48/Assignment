<html>
<head></head>
<body>
<?php
$connect = @mysql_connect('localhost','root','');
	mysql_select_db('form_db',$connect);
	$select_query = "SELECT * FROM users";
	$fetch_query = mysql_query($select_query,$connect);
?>
<table id="users-table">
			<thead>
				<tr>
					<th>ID</th>
					<th>name</th>
					<th>Email</th>
					<!--<th>Flat No</th>-->
					<th>Phone</th>
					<!--<th>Created</th>-->
					<th>Update</th>
				</tr>
			</thead>	
			<tbody>
				<?php
					$i = 1;
					while($result = mysql_fetch_assoc($fetch_query)){
				?>
			<tr>
				<td><?php echo $i;?></td>
				<td><td><?php echo $result['name'];?></td>
				<td><?php echo $result['email'];?></td>
			    <td><?php echo $result['phone'];?></td>	
				<td><a href="update.php?id=<?php echo $result['user_id'];?>">Update</a></td>
				<td><a href="delete.php?id=<?php echo $result['user_id'];?>">Delete</a></td>
			</tr>
			<?php
					$i++;
					}
			?>
			</tbody>
</table>
</body>
</html>