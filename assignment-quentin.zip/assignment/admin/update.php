<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
	<meta content="" name="description">
	<meta content="" name="author">
	<title>Update</title>
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"><!-- Custom styles for this template -->
	<link href="css/admin.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body class="update-bg bg-gradient-primary">
	<div class="container">
		<div class="card o-hidden border-0 shadow-lg my-5">
			<div class="card-body p-0">
				<!-- Nested Row within Card Body -->
				<div class="row">
					<div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
					<div class="col-lg-7">
						<div class="p-5">
							<div class="text-center">
								<h1 class="h4 text-gray-900 mb-4">Update Details</h1>
							</div>
							<?php
							    if(isset($_GET['id'])){
							    $id = $_GET['id'];
							    $connect = @mysql_connect('localhost','root','');
							    mysql_select_db('form_db',$connect);
							    $select_query = "SELECT * FROM users WHERE user_id = $id";
							    $fetch_query = mysql_query($select_query,$connect);
							    $result = mysql_fetch_assoc($fetch_query);
							 ?>
							<form action="update-submit.php" class="user" method="post">
								<input name="userid" type="hidden" value="<?php echo $result['user_id'];?>">
								<div class="form-group">
									<input class="form-control form-control-user" name="name" type="text" value="<?php echo $result['name'];?>">
								</div>
								<div class="form-group">
									<input class="form-control form-control-user" name="mailid" type="email" value="<?php echo $result['email'];?>">
								</div>
								<div class="form-group">
									<input class="form-control form-control-user" name="contact" type="phone" value="<?php echo $result['phone'];?>">
								</div><input class="btn btn-primary btn-user btn-block" id="update-details" name="update-details" type="submit" value="Update">
							</form><?php
							                }
							            ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- Bootstrap core JavaScript-->
	<script src="vendor/jquery/jquery.min.js">
	</script> 
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js">
	</script> <!-- Core plugin JavaScript-->
	 
	<script src="vendor/jquery-easing/jquery.easing.min.js">
	</script> <!-- Custom scripts for all pages-->
	 
	<script src="js/admin.min.js">
	</script>
</body>
</html>