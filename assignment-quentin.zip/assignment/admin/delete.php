<?php
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$connect = @mysql_connect('localhost','root','');
	mysql_select_db('form_db',$connect);
	$delete_query = "DELETE FROM users WHERE user_id = $id";
	mysql_query($delete_query,$connect);
	header("Location: dashboard.php");
}
?>