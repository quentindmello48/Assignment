<?php
if(isset($_POST['update-details'])){
	$connect = @mysql_connect('localhost','root','');
	mysql_select_db('form_db',$connect);
	$id = $_POST['userid'];
	$name = $_POST['name'];
	$email = $_POST['mailid'];
	$phone = $_POST['contact'];
	$select_query = "SELECT * FROM users WHERE user_id = $id";
	$fetch_query = mysql_query($select_query,$connect);
	if(mysql_num_rows($fetch_query) > 0){
		$update_query = "UPDATE users SET name='$name',email='$email',phone='$phone' WHERE user_id='$id'";  
		mysql_query($update_query,$connect);
		header("Location: dashboard.php");
        exit;
	}
}
?>