- Have created two folders:
1. Admin 
2. Website
The form submission is in the website folder(website/form-page.php)
The table is viewed,updated and deleted in admin folder(admin/dashboard.php)

- Download XAMP/WAMP to run these files on localhost.
- Form page - (http://localhost/assignment/website/form-page.php)
- Admin Dashboard - (http://localhost/assignment/admin/dashboard.php)

- Import database 'form_db' in Phpmyadmin.