<!DOCTYPE html>
<html lang="en">
<head>
  <title>Thank You</title>
  <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/form-css.css">
</head>
<body>
<header>
<div class="container">
<div class="row">
    <div class="col-sm-12 col-md-12">
		<nav class="navbar navbar-default">
			<div class="navbar-header">
			    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				    <span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>                        
				</button>
				<a class="navbar-brand" href="http://localhost/assignment/website/form-page.php"><img src="images/logo.png" class="logo-img" alt="Website Logo"></a>
			</div>
		<div class="collapse navbar-collapse" id="myNavbar">	
			<ul class="nav navbar-nav">
				<li class="active"><a href="#">Home</a></li>
				<li><a href="#">About</a></li>
				<li><a href="#">Careers</a></li>
				<li><a href="#">Contact</a></li>
			</ul>
		</div>	
		</nav>
    </div>
</div>
</div>
</header>
<div class="site-banner">
<div class="container">
		<div class="row">
		    <div class="col-sm-12 col-md-12">
				<h1>THANK YOU</h1>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
				<p><a href="form-page.php" class="site-link">Feel free to browse our site.</a></p>

			</div>
	    </div>
</div>
</div>
<footer>
	<div class="container">
		<div class="row">
			 <div class="col-sm-6 col-md-6">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
			 </div>
			 <div class="col-sm-6 col-md-6">
				<p class="copyright">© 2020 Demo</p>
			 </div>
		</div>
	</div>
</footer>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>