<?php
if(isset($_POST['form-submit'])){
	$connect = @mysql_connect('localhost','root','');
	mysql_select_db('form_db',$connect);
	$name = $_POST['name'];
	$email = $_POST['mailid'];
	$phone = $_POST['contact'];
	$insert_query = "INSERT INTO users(name,email,phone)VALUES('$name','$email','$phone')";
	mysql_query($insert_query,$connect);
	header("Location:thankyou.php");
}
?>